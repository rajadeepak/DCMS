package com;

public class Record {

	String First_name;
	String Last_name;
	//String Record_ID;
	Record(){}
	Record(String firstname,String lastname){
		First_name=firstname;
		Last_name=lastname;
	}
	
}
