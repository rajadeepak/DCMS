package com;

public class Record {

	String First_name;
	String Last_name;
	String Record_ID;
	Record(String firstname,String lastname, String bloop){
		First_name=firstname;
		Last_name=lastname;
		Record_ID=bloop;
	}
	
}
